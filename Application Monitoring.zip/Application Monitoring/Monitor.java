import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.DropMode;
import javax.swing.JScrollBar;
import javax.swing.JTextPane;
import java.awt.TextArea;
import java.awt.SystemColor;

public class Monitor extends JFrame {

	private JFrame frame;
	private JPanel contentPane;
	private JTextField monitoring_1;
	private JTextField txtTotalPhysicalMemory;
	private JTextField totalphysicalmemory;
	private JTextField txtPhysicalMemory;
	private JTextField txtFreePhysicalMemory;
	private JTextField freephysicalmemory;
	private JTextField txtVirtualMemory;
	private JTextField txtTotalVirtualMemory;
	private JTextField totalvirtualmemory;
	private JTextField txtFreeVirtualMemory;
	private JTextField freevirtualmemory;
	private JTextField txtLoadPercentage;
	private JTextField loadpercentage;
	private JTextField dateTime;
	private JLabel lblNewLabel;
	private JLabel lblDateAndTime;
	private JLabel lblNoteRefresh; 
	private JTextField txtAdvanceMonitoring;
	private JLabel lblClickingTheButton;
	private JLabel lblWillOpenUp;
	private JButton JMX;
	private JButton ResourceMonitor;
	private JButton btnRefresh;
	private JTextField txtAwsRemoteMonitoring;
	private TextArea ipconfig;
	private JTextArea txtrAmazonWebServices;
	private JTextArea Description;
	private JButton btnStartAwsRemote;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Monitor window = new Monitor();
					window.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
	}

	/**
	 * Create the application.
	 */
	public Monitor() {
//		initialize();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1381, 716);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmNew = new JMenuItem("New");
		mnFile.add(mntmNew);
		
		JMenuItem mntmEdit = new JMenuItem("Edit");
		mnFile.add(mntmEdit);
		
		JMenu mnSource = new JMenu("Source");
		menuBar.add(mnSource);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(12, 0, 1339, 643);
		contentPane.add(tabbedPane);
		
			JPanel monitoring = new JPanel();
			tabbedPane.addTab("Local Monitoring", null, monitoring, null);
			monitoring.setLayout(null);
			
			monitoring_1 = new JTextField();
			monitoring_1.setText("Monitoring Processes Desk\r\n");
			monitoring_1.setHorizontalAlignment(SwingConstants.CENTER);
			monitoring_1.setFont(new Font("Tahoma", Font.ITALIC, 35));
			monitoring_1.setEditable(false);
			monitoring_1.setColumns(10);
			monitoring_1.setBackground(Color.LIGHT_GRAY);
			monitoring_1.setBounds(12, 25, 1310, 47);
			monitoring.add(monitoring_1);
			
			txtTotalPhysicalMemory = new JTextField();
			txtTotalPhysicalMemory.setHorizontalAlignment(SwingConstants.CENTER);
			txtTotalPhysicalMemory.setFont(new Font("Tahoma", Font.PLAIN, 20));
			txtTotalPhysicalMemory.setBackground(Color.LIGHT_GRAY);
			txtTotalPhysicalMemory.setEditable(false);
			txtTotalPhysicalMemory.setText("Total Physical Memory (in bytes)");
			txtTotalPhysicalMemory.setBounds(12, 145, 342, 47);
			monitoring.add(txtTotalPhysicalMemory);
			txtTotalPhysicalMemory.setColumns(10);
			
			totalphysicalmemory = new JTextField();
			totalphysicalmemory.setHorizontalAlignment(SwingConstants.CENTER);
			totalphysicalmemory.setFont(new Font("Tahoma", Font.PLAIN, 16));
			totalphysicalmemory.setBackground(Color.WHITE);
			totalphysicalmemory.setEditable(false);
			totalphysicalmemory.setBounds(366, 145, 342, 47);
			monitoring.add(totalphysicalmemory);
			totalphysicalmemory.setColumns(10);
						
			txtPhysicalMemory = new JTextField();
			txtPhysicalMemory.setBackground(Color.LIGHT_GRAY);
			txtPhysicalMemory.setHorizontalAlignment(SwingConstants.CENTER);
			txtPhysicalMemory.setFont(new Font("Tahoma", Font.PLAIN, 30));
			txtPhysicalMemory.setText("Physical Memory");
			txtPhysicalMemory.setBounds(12, 85, 696, 47);
			monitoring.add(txtPhysicalMemory);
			txtPhysicalMemory.setColumns(10);
			
			txtFreePhysicalMemory = new JTextField();
			txtFreePhysicalMemory.setFont(new Font("Tahoma", Font.PLAIN, 20));
			txtFreePhysicalMemory.setHorizontalAlignment(SwingConstants.CENTER);
			txtFreePhysicalMemory.setBackground(Color.LIGHT_GRAY);
			txtFreePhysicalMemory.setEditable(false);
			txtFreePhysicalMemory.setText("Free Physical Memory (in bytes)");
			txtFreePhysicalMemory.setBounds(12, 205, 342, 47);
			monitoring.add(txtFreePhysicalMemory);
			txtFreePhysicalMemory.setColumns(10);
			
			freephysicalmemory = new JTextField();
			freephysicalmemory.setHorizontalAlignment(SwingConstants.CENTER);
			freephysicalmemory.setFont(new Font("Tahoma", Font.PLAIN, 16));
			freephysicalmemory.setBackground(Color.WHITE);
			freephysicalmemory.setEditable(false);
			freephysicalmemory.setBounds(366, 205, 342, 47);
			monitoring.add(freephysicalmemory);
			freephysicalmemory.setColumns(10);
		
			txtVirtualMemory = new JTextField();
			txtVirtualMemory.setHorizontalAlignment(SwingConstants.CENTER);
			txtVirtualMemory.setEditable(false);
			txtVirtualMemory.setFont(new Font("Tahoma", Font.PLAIN, 30));
			txtVirtualMemory.setBackground(Color.LIGHT_GRAY);
			txtVirtualMemory.setText("Virtual Memory");
			txtVirtualMemory.setBounds(12, 265, 696, 47);
			monitoring.add(txtVirtualMemory);
			txtVirtualMemory.setColumns(10);
			
			txtTotalVirtualMemory = new JTextField();
			txtTotalVirtualMemory.setHorizontalAlignment(SwingConstants.CENTER);
			txtTotalVirtualMemory.setFont(new Font("Tahoma", Font.PLAIN, 20));
			txtTotalVirtualMemory.setBackground(Color.LIGHT_GRAY);
			txtTotalVirtualMemory.setText("Total Virtual Memory (in bytes)");
			txtTotalVirtualMemory.setBounds(12, 325, 342, 47);
			monitoring.add(txtTotalVirtualMemory);
			txtTotalVirtualMemory.setColumns(10);
			
			totalvirtualmemory = new JTextField();
			totalvirtualmemory.setHorizontalAlignment(SwingConstants.CENTER);
			totalvirtualmemory.setFont(new Font("Tahoma", Font.PLAIN, 16));
			totalvirtualmemory.setBackground(Color.WHITE);
			totalvirtualmemory.setEditable(false);
			totalvirtualmemory.setBounds(366, 325, 342, 47);
			monitoring.add(totalvirtualmemory);
			totalvirtualmemory.setColumns(10);
			
			txtFreeVirtualMemory = new JTextField();
			txtFreeVirtualMemory.setFont(new Font("Tahoma", Font.PLAIN, 20));
			txtFreeVirtualMemory.setBackground(Color.LIGHT_GRAY);
			txtFreeVirtualMemory.setEditable(false);
			txtFreeVirtualMemory.setHorizontalAlignment(SwingConstants.CENTER);
			txtFreeVirtualMemory.setText("Free Virtual Memory (in bytes)");
			txtFreeVirtualMemory.setBounds(12, 385, 342, 47);
			monitoring.add(txtFreeVirtualMemory);
			txtFreeVirtualMemory.setColumns(10);
			
			freevirtualmemory = new JTextField();
			freevirtualmemory.setHorizontalAlignment(SwingConstants.CENTER);
			freevirtualmemory.setFont(new Font("Tahoma", Font.PLAIN, 16));
			freevirtualmemory.setBackground(Color.WHITE);
			freevirtualmemory.setEditable(false);
			freevirtualmemory.setBounds(366, 385, 342, 47);
			monitoring.add(freevirtualmemory);
			freevirtualmemory.setColumns(10);
		
			txtLoadPercentage = new JTextField();
			txtLoadPercentage.setFont(new Font("Tahoma", Font.PLAIN, 30));
			txtLoadPercentage.setEditable(false);
			txtLoadPercentage.setHorizontalAlignment(SwingConstants.CENTER);
			txtLoadPercentage.setBackground(Color.LIGHT_GRAY);
			txtLoadPercentage.setText("Load Percentage (%)");
			txtLoadPercentage.setBounds(12, 445, 696, 47);
			monitoring.add(txtLoadPercentage);
			txtLoadPercentage.setColumns(10);
			
			loadpercentage = new JTextField();
			loadpercentage.setFont(new Font("Tahoma", Font.PLAIN, 16));
			loadpercentage.setHorizontalAlignment(SwingConstants.CENTER);
			loadpercentage.setBounds(12, 502, 696, 47);
			monitoring.add(loadpercentage);
			loadpercentage.setColumns(10);
	
			dateTime = new JTextField();
			dateTime.setBackground(Color.WHITE);
			dateTime.setEditable(false);
			dateTime.setHorizontalAlignment(SwingConstants.CENTER);
			dateTime.setFont(new Font("Tahoma", Font.BOLD, 20));
			dateTime.setBounds(740, 179, 582, 47);
			monitoring.add(dateTime);
			dateTime.setColumns(10);
		
			lblNewLabel = new JLabel("All monitorization are based on the current");
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblNewLabel.setBounds(840, 116, 395, 25);
			monitoring.add(lblNewLabel);
			
			lblDateAndTime = new JLabel("date and time (GMT +8) :");
			lblDateAndTime.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblDateAndTime.setBounds(932, 145, 232, 21);
			monitoring.add(lblDateAndTime);
			
			lblNoteRefresh = new JLabel("Note : Refresh may take up to 5 seconds");
			lblNoteRefresh.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
			lblNoteRefresh.setBounds(740, 281, 382, 25);
			monitoring.add(lblNoteRefresh);
			
			txtAdvanceMonitoring = new JTextField();
			txtAdvanceMonitoring.setBackground(Color.LIGHT_GRAY);
			txtAdvanceMonitoring.setFont(new Font("Tahoma", Font.PLAIN, 20));
			txtAdvanceMonitoring.setHorizontalAlignment(SwingConstants.CENTER);
			txtAdvanceMonitoring.setText("Advance Monitoring");
			txtAdvanceMonitoring.setBounds(740, 325, 582, 47);
			monitoring.add(txtAdvanceMonitoring);
			txtAdvanceMonitoring.setColumns(10);
			
			lblClickingTheButton = new JLabel("Clicking the button below will open up");
			lblClickingTheButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lblClickingTheButton.setBounds(874, 385, 278, 25);
			monitoring.add(lblClickingTheButton);
			
			lblWillOpenUp = new JLabel("a new monitoring window");
			lblWillOpenUp.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lblWillOpenUp.setBounds(911, 407, 197, 25);
			monitoring.add(lblWillOpenUp);
			
			JMX = new JButton("Monitoring via JMX");
			JMX.setFont(new Font("Tahoma", Font.PLAIN, 20));
			JMX.setBounds(740, 449, 582, 47);
			monitoring.add(JMX);
			JMX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try{
     					Process proc = Runtime.getRuntime().exec("cmd /C \"cd \\\"C:\\Users\\Amzar\\Desktop & jconsole.lnk");
     			        proc.getInputStream();
     			       
     				}catch (Exception exp) {
     					exp.printStackTrace();
				}
				}
			});
			
			
			ResourceMonitor = new JButton("Open Resource Monitor");
			ResourceMonitor.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
//					-------------------Monitoring via Resource Monitor Application-------------------------
					try{
	     					Process proc = Runtime.getRuntime().exec("cmd /C \"perfmon /res");
	     			        proc.getInputStream();
	     			       
	     				}catch (Exception exp) {
	     					exp.printStackTrace();
	     				}
				}
			});
			ResourceMonitor.setFont(new Font("Tahoma", Font.PLAIN, 20));
			ResourceMonitor.setBounds(740, 502, 581, 47);
			monitoring.add(ResourceMonitor);
			
			btnRefresh = new JButton("Refresh");
			btnRefresh.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					{
				getMethod();
				 	}
				}	
			});
			btnRefresh.setBounds(952, 239, 197, 40);
			monitoring.add(btnRefresh);
			
			JPanel AWSMonitoring = new JPanel();
			tabbedPane.addTab("AWS Remote Monitoring", null, AWSMonitoring, null);
			AWSMonitoring.setLayout(null);
			
			txtAwsRemoteMonitoring = new JTextField();
			txtAwsRemoteMonitoring.setHorizontalAlignment(SwingConstants.CENTER);
			txtAwsRemoteMonitoring.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 35));
			txtAwsRemoteMonitoring.setBackground(Color.GRAY);
			txtAwsRemoteMonitoring.setEditable(false);
			txtAwsRemoteMonitoring.setText("AWS Remote Monitoring");
			txtAwsRemoteMonitoring.setBounds(10, 11, 1314, 52);
			AWSMonitoring.add(txtAwsRemoteMonitoring);
			txtAwsRemoteMonitoring.setColumns(10);
			
			ipconfig = new TextArea();
			ipconfig.setEditable(false);
			ipconfig.setFont(new Font("Times New Roman", Font.PLAIN, 12));
			ipconfig.setBounds(826, 88, 498, 446);

			AWSMonitoring.add(ipconfig);
			{
				try{
					Process proc = Runtime.getRuntime().exec("cmd /C \"ipconfig");
					InputStream is = proc.getInputStream();
					int i = -1;
					StringBuilder buf = new StringBuilder();
					while ((i = is.read()) != -1) {
				        	
				            buf.append((char)i);
				          
				        }
				        ipconfig.setText(buf.toString());
				        
				        txtrAmazonWebServices = new JTextArea();
				        txtrAmazonWebServices.setWrapStyleWord(true);
				        txtrAmazonWebServices.setTabSize(14);
				        txtrAmazonWebServices.setFont(new Font("Tahoma", Font.PLAIN, 14));
				        txtrAmazonWebServices.setLineWrap(true);
				        txtrAmazonWebServices.setText("Reason : To view the performance of the client(s) remotely so that users know how well and fine the client is.\r\n\r\nSteps:\r\n1. Click \"Get Data Into Database\" button\r\n2. Once the process is completed, choose a node file to execute on Command Prompt.\r\nExample : \"$>node average.js\"\r\n3. After executing the file, click the \"View Graph\" button to view the graph on browser.");
				        txtrAmazonWebServices.setBackground(Color.LIGHT_GRAY);
				        txtrAmazonWebServices.setForeground(Color.BLACK);
				        txtrAmazonWebServices.setEditable(false);
				        txtrAmazonWebServices.setBounds(10, 133, 789, 144);
				        AWSMonitoring.add(txtrAmazonWebServices);
				        
				        Description = new JTextArea();
				        Description.setEditable(false);
				        Description.setFont(new Font("Tahoma", Font.BOLD, 23));
				        Description.setBackground(Color.LIGHT_GRAY);
				        Description.setText("Description of Monitoring");
				        Description.setBounds(10, 88, 789, 52);
				        AWSMonitoring.add(Description);
				        
				        btnStartAwsRemote = new JButton("Amazon Web Service Website");
				        btnStartAwsRemote.setFont(new Font("Tahoma", Font.BOLD, 20));
				        btnStartAwsRemote.addActionListener(new ActionListener() {
				        	public void actionPerformed(ActionEvent arg0) {
				        		openWebPage("https://us-east-2.console.aws.amazon.com/ec2/v2/home?region=us-east-2#Instances:sort=instanceId");
				        	}

							private void openWebPage(String url) {
								try {
									java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));;
								}
								catch (java.io.IOException e) {
									System.out.println(e.getMessage());
								}
								
							}
				        });
				        btnStartAwsRemote.setBounds(10, 540, 1314, 52);
				        AWSMonitoring.add(btnStartAwsRemote);
				        
				        JButton btnOpenGraph = new JButton("View Graph");
				        btnOpenGraph.setFont(new Font("Tahoma", Font.BOLD, 20));
				        btnOpenGraph.setMnemonic(KeyEvent.VK_E);
				        btnOpenGraph.setActionCommand("enable");
				        btnOpenGraph.setEnabled(false);
				        
				        JButton btnRunAWS = new JButton("Get Data Into Database");
				        btnRunAWS.setFont(new Font("Tahoma", Font.BOLD, 20));
				        btnRunAWS.setMnemonic(KeyEvent.VK_D);
				        btnRunAWS.setActionCommand("disable");
				        btnRunAWS.addActionListener(new ActionListener() {
				        	public void actionPerformed(ActionEvent arg0) {
				        		
				        		 if ("disable".equals(arg0.getActionCommand())) {
				        		        btnRunAWS.setEnabled(false);
				        		        btnOpenGraph.setEnabled(true);
				        		    } else {
				        		        btnRunAWS.setEnabled(true);
				        		        btnOpenGraph.setEnabled(false);
				        		    }
				        		    btnRunAWS.addActionListener(this);
							        btnOpenGraph.addActionListener(this);
							        
				        		try {
				        			  
				        			  //Parsing the output from CMD
				        		  String line,combAll="";

				        		    Process p = Runtime.getRuntime().exec("cmd /C \"aws cloudwatch get-metric-statistics --namespace AWS/EC2 --metric-name CPUUtilization --dimensions Name=InstanceId,Value=i-0361c583ff5541aec --statistics Minimum Maximum Average SampleCount --start-time 2017-12-11T012:00:00 --end-time 2017-12-11T13:05:00 --period 360");;
				        		    BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

				        		    while ((line = input.readLine()) != null)
				        		      combAll+="\n"+line;
				        		    input.close();
				        		   
//				        		    System.out.println(combAll);
				        		    
				        		    final JSONObject obj = new JSONObject(combAll);
				        		    final JSONArray Datapoints = obj.getJSONArray("Datapoints");
				        		    final int n = Datapoints.length();
				        		    for (int i = 0; i < n; ++i) {
				        		      final JSONObject person = Datapoints.getJSONObject(i);
				        		      Double SampleCount = person.getDouble("SampleCount"); 
				        		      System.out.print(SampleCount);
				        		      System.out.print(", ");
				        		      Double Average = person.getDouble("Average");
				        		      System.out.print(Average);
				        		      System.out.print(", ");
				        		      Double Maximum = person.getDouble("Maximum");
				        		      System.out.print(Maximum);
				        		      System.out.print(", ");
				        		      Double Minimum = person.getDouble("Minimum");
				        		      System.out.print(Minimum);
				        		      System.out.print(", ");
				        		      String Unit = person.getString("Unit");
				        		      System.out.print(Unit);
				        		      System.out.print(", ");
				        		      String Timestamp = person.getString("Timestamp");
				        		      Timestamp=Timestamp.replace('T', ' ');
				        		      Timestamp=Timestamp.substring(0,Timestamp.length()-1);
				        		      System.out.print(Timestamp);
				        		      System.out.println("");
				        		     			        		      
				        					Class.forName("com.mysql.jdbc.Driver");  
				        					Connection con=DriverManager.getConnection(  
				        							"jdbc:mysql://localhost:3306/CPUData", "root", "apple8195");
				        		                   
				        					System.out.println("Database is connected");
				        					ipconfig.setText("\n\n\n======================================================================");
				        					ipconfig.append("\n\nDatabase has been connected");
				        					ipconfig.append("\n\nInserting data into the database");
				        					
				        					Statement stmt=con.createStatement();  
				        					String st = "INSERT INTO cpuutil (SampleCount, UNIT, AVERAGES, MAXIMUM, MINIMUM, Timestamp)"+ "VALUES (" + SampleCount + ", \'" +Unit+ "\' ," + Average + ","+ Maximum + "," + Minimum + ", \'" + Timestamp + "\')";
				        					System.out.println(st);
				        					ipconfig.append("\n\nCommand :");
				        					ipconfig.append("\n" +st);
				        					stmt.executeUpdate(st);		
				        					ipconfig.append("\n\n . \n\n . \n\n . \nData has been insert succesfully! \n\n ");
				        					
				        					ipconfig.append(". \n\n . \n\n . \nExecuting command via Command Prompt  \n\n ");
				        					Process graph = Runtime.getRuntime().exec("cmd /C \"cd \\\"C:\\Users\\Amzar\\Desktop node plotly.js");
				         			        graph.getInputStream();				    
				         			        ipconfig.append("\nCommand executed! ");
				        		    }
				        		    }catch(Exception e)
				        		    	{ System.out.println(e); 
				        		    	ipconfig.append("\n\n . \n\n . \n\n .");
				        		    	ipconfig.append("\n\n\n======================================================================");
				        		    	ipconfig.append(" \nError(s) Occured! \n\nError(s) caused by : \n" +e);
				        		    	}
				        	}
				        });
				        btnRunAWS.setBounds(206, 300, 423, 65);
				        AWSMonitoring.add(btnRunAWS);
				        
				        JTextArea txtrSomethingToWrite = new JTextArea();
				        txtrSomethingToWrite.setEditable(false);
				        txtrSomethingToWrite.setBackground(SystemColor.windowBorder);
				        txtrSomethingToWrite.setForeground(new Color(0, 0, 0));
				        txtrSomethingToWrite.setText("The API will collect the data from the instance and stores inside the CPUData database.");
				        txtrSomethingToWrite.setBounds(68, 376, 709, 22);
				        AWSMonitoring.add(txtrSomethingToWrite);
				        
				      
				        
				       
				        btnOpenGraph.addActionListener(new ActionListener() {
				        	public void actionPerformed(ActionEvent arg0) {
				        		openWebPage("https://plot.ly/~amkun8195/0");
				        		ipconfig.append("\n\n\n======================================================================\n\n");
				        		ipconfig.append("Plotting graph via Plotty\n\n . \n\n . \n\n . \n");
				        		ipconfig.append("Graph plotted!");
				        		ipconfig.append("\n\n\nHave you run your node file on Command Prompt? \n\n ");
				        		ipconfig.append("The cause of an unploated graph is due to the node file that has not been running!");
				        	}

							private void openWebPage(String url) {
								try {
									java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));;
								}
								catch (java.io.IOException e) {
									System.out.println(e.getMessage());
								}
							
							}
				        });
				        btnOpenGraph.setBounds(206, 409, 423, 65);
				        AWSMonitoring.add(btnOpenGraph);
				        
				        JTextArea txtrSomethingHereToo = new JTextArea();
				        txtrSomethingHereToo.setEditable(false);
				        txtrSomethingHereToo.setBackground(SystemColor.windowBorder);
				        txtrSomethingHereToo.setText("This will open up the graph on the default browser.");
				        txtrSomethingHereToo.setBounds(176, 485, 480, 22);
				        AWSMonitoring.add(txtrSomethingHereToo);
				        proc.waitFor();
					}
				catch (Exception exp) {
					exp.printStackTrace();
				}
			}
					
			getMethod(); 
	}
	
	public void getMethod() {
		try{
			Process proc2 = Runtime.getRuntime().exec("cmd /C \"wmic os get FreeVirtualMemory /format : table");
			Process proc3 = Runtime.getRuntime().exec("cmd /C \"Date /T & Time /T");
			Process proc4 = Runtime.getRuntime().exec("cmd /C \"wmic OS get FreePhysicalMemory /format : table");
			Process proc5 = Runtime.getRuntime().exec("wmic ComputerSystem get TotalPhysicalMemory /format : table");
			Process proc6 = Runtime.getRuntime().exec("cmd /C \"wmic OS get TotalVirtualMemorySize /format : table");
			Process proc7 = Runtime.getRuntime().exec("cmd /C \"wmic cpu get loadpercentage /format : Value");
			
			 InputStream is2 = proc2.getInputStream();
			 InputStream is3 = proc3.getInputStream();
			 InputStream is4 = proc4.getInputStream();
			 InputStream is5 = proc5.getInputStream();
			 InputStream is6 = proc6.getInputStream();
			 InputStream is7 = proc7.getInputStream();
			 
			 int i2 = -1;
			 int i3 = -1;
			 int i4 = -1;
			 int i5 = -1;
			 int i6 = -1;
			 int i7 = -1;
			 
			 StringBuilder buf2 = new StringBuilder();
			 StringBuilder buf3 = new StringBuilder();
			 StringBuilder buf4 = new StringBuilder();
			 StringBuilder buf5 = new StringBuilder();
			 StringBuilder buf6 = new StringBuilder();
			 StringBuilder buf7 = new StringBuilder();
			 
			 while ((i2 = is2.read()) != -1) {
		        	
		            buf2.append((char)i2);
		          
		        }
		        freevirtualmemory.setText(buf2.toString());
		        proc2.waitFor();
		        
		     while ((i3 = is3.read()) != -1) {
		        	
		            buf3.append((char)i3);
		          
		        }
		        dateTime.setText(buf3.toString()  );
		        proc3.waitFor();
		   
		     while ((i4 = is4.read()) != -1) {
		        	
		            buf4.append((char)i4);
		          
		        }
		        freephysicalmemory.setText(buf4.toString());
		        proc4.waitFor();
		        
		        while ((i5 = is5.read()) != -1) {
		        	
		            buf5.append((char)i5);
		          
		        }
		        totalphysicalmemory.setText(buf5.toString());
		        proc5.waitFor();
			
		        while ((i6 = is6.read()) != -1) {
		        	  
		            buf6.append((char)i6);
		          
		        }
		        totalvirtualmemory.setText(buf6.toString());
		        proc6.waitFor();
		        
		        while ((i7 = is7.read()) != -1) {
		        	
		            buf7.append((char)i7);
		          
		        }
		        loadpercentage.setText(buf7.toString());
		        proc7.waitFor();
		       
		}catch (Exception exp) {
			exp.printStackTrace();
		}
	}
}

	
	
