var plotly = require('plotly')("amkun8195", "71d7moRUa7G2IDqgBhKx")
var mysql = require('mysql');
  var con = mysql.createConnection({
   host: "localhost",
   user: "root",
   password: "apple8195",
   database: "cpudata"
 });

 con.connect(function(err) {
   if (err) throw "An error has occured when connecting to the database!";
   //Select only "name" and "address" from "customers":
   con.query("SELECT * FROM cpuutil ORDER BY Timestamp ASC", function (err, result, fields) {
 
 var array = [];
 var array2 = [];

 for (var i = 0; i < result.length; i++){

  array.splice(0, 0, result[i].Timestamp);
 }

 for (var j = 0; j < result.length; j++){
  array2.splice(0, 0, result[j].id);

 }

 console.log(array.join());
 console.log(array2.join());


var data = [{x: array, y:array2, type: 'scatter', mode: 'line'}];
var layout = {fileopt : "overwrite", filename : "simple-node-example"};

plotly.plot(data, layout, function (err, msg) {
  if (err) return console.log(err);
  console.log(msg);
});

});
});
   // });